These files form xsd to the check the header of the AS4 message that is sent to AS4. One can check their header against
the XSD "main.xsd" to see if there are any glaring issues.