# dms-public
Changelog from version 1.0.0 to 1.1.1:
* Declaration/Submitter/ID - Removed ID for submitter.
* Declaration/Agent/Address - Temporarily added mandatory address on representative (Agent - 3/19).
* Declaration/GoodsShipment/AdditionalDocument/SequenceNumeric - is added, and is mandatory.
* Declaration/GoodsShipment/AdditionalInformation/SequenceNumeric - is added, and is mandatory.
* Declaration/GoodsShipment/Consignment/GoodsLocation - is now mandatory.
* Declaration/GoodsShipment/CustomsValuation/FreightChargeAmount - If CustomsValuation is filled, then is now mandatory.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/AdditionalDocument - Temporarily added AdditionalDocument is mandatory.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/AdditionalDocument/SequenceNumeric -  is added, and is mandatory.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/AdditionalDocument/* -  All subfields under AdditionalDocument are mandatory.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/AdditionalInformation/SequenceNumeric -  is added, and is mandatory.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/AdditionalInformation/* -  StatementCode and StatementTypeCode are mandatory, if AdditionalInformation is used.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/GovernmentProcedure -  Can now occur 3 times.
* Declaration/GoodsShipment/GovernmentAgencyGoodsItem/GovernmentProcedure/SequenceNumeric -  SequenceNumeric is added, and is mandatory.
* Declaration/GoodsShipment/Importer/Address/CountryCode - Temporarily added CountryCode is mandatory.